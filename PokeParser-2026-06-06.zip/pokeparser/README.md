# PokeParser

OCR tool: drop PokeNexus screenshots in → get a styled Excel spreadsheet with all IVs, EVs, natures, and Smogon nature recommendations.

**Accuracy: ~97.7% across tested screenshots.**

---

## Prerequisites — Tesseract OCR (required on every machine)

Tesseract is the OCR engine. **It must be installed before PokeParser will work.**

| Platform | Install |
|---|---|
| **Windows** | Download [tesseract-ocr-w64-setup-5.3.3.exe](https://github.com/UB-Mannheim/tesseract/releases/download/v5.3.3.20231005/tesseract-ocr-w64-setup-5.3.3.20231005.exe) — keep the default path |
| **macOS** | `brew install tesseract` |
| **Linux** | `sudo apt install tesseract-ocr` / `sudo dnf install tesseract` |

---

## Building the App (first time)

You need Python 3.10+ and Tesseract installed first.

### Windows
1. Install Python from **https://python.org** — check **"Add Python to PATH"**
2. Double-click **`install_windows.bat`**
3. Output: `dist\PokeParser\PokeParser.exe` + Desktop shortcut

### macOS
```bash
bash install_mac.sh
```
Output: `/Applications/PokeParser.app`

### Linux
```bash
bash install_linux.sh
```
Output: `dist/PokeParser/PokeParser` + desktop entry

The build takes 60–120 seconds. Packages are cached so subsequent rebuilds are faster.

---

## Distributing to Other Players

**What recipients always need: Tesseract installed (see above). That's the only dependency.**

### Windows
Zip the entire `dist\PokeParser\` folder and send it.
Recipient unzips and double-clicks `PokeParser.exe`. No Python needed.

### macOS
Send `PokeParser.app`.
If macOS blocks it: **System Settings → Privacy & Security → Open Anyway**

### Linux
Zip the `dist/PokeParser/` folder and send it.
Recipient unzips and runs `./PokeParser`.

---

## Usage

1. Launch PokeParser
2. Drop screenshots or a folder onto the queue, or use **+ Files** / **+ Folder**
3. Click **▶ Parse Screenshots**
4. Click **💾 Save Locally** or **☁ Upload to Drive**

### Screenshot naming conventions
| Situation | Filename example |
|---|---|
| Shiny | `S Gengar.png` or `S_Gengar.png` |
| Specialty form | `Chandelure-Halloween.png`, `Gyarados-Christmas.png` |
| Multiple same species | `Abra 1.png`, `Abra 2.png` |
| Any other name | Works — name/shiny falls back to filename |

The app reads the Pokemon name, level, and shiny status directly from the in-game label (`Lv 25 [S]Gengar`). The filename is only used as a fallback if the background is too busy to read.

---

## Google Drive Setup (optional)

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create a project → Enable **Google Drive API**
3. Credentials → Create → **OAuth 2.0 Client ID** → Desktop App → Download `credentials.json`
4. In PokeParser: **☁ Drive Setup** → Browse to `credentials.json` → Authorise

One-time per machine. Token saved to `~/.pokeparser_token.pickle`.

---

## Output Spreadsheet Columns

File · Pokemon · Level · Shiny · Pokédex · Type · **Nature** *(green = Smogon USUM recommended)* · Happiness · Ability · Catcher · HP Total · HP Max · **HP IV** · HP EV · Atk · **Atk IV** · Atk EV · Def · **Def IV** · Def EV · Spec Atk · **Spec Atk IV** · Spec Atk EV · Spec Def · **Spec Def IV** · Spec Def EV · Speed · **Speed IV** · Speed EV · Parse Errors

IV columns are **green** when the value is 30 or 31.
Specialty forms (`-Halloween`, `-Christmas`) use their base species for Smogon lookup.

Filename: `PokeParser-YYYY-MM-DD_HHMMSS.xlsx`

---

## Known Limits

- Level is blank for ~8 screenshot types where the game background completely obscures the left panel text (busy gym/battle backgrounds). All other fields still parse correctly for these.
- Single-digit OCR variance on very low stats (level 1–5 Pokemon).
