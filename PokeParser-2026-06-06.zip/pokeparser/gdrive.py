"""
gdrive.py
Google Drive upload helper for PokeParser.
Handles OAuth2 flow and file upload to a user-configured folder.
Credentials are stored locally per-user (never hardcoded).
"""

import os
import json
import pickle

try:
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload
    GDRIVE_AVAILABLE = True
except ImportError:
    GDRIVE_AVAILABLE = False

SCOPES = ["https://www.googleapis.com/auth/drive.file"]
TOKEN_FILE = os.path.join(os.path.expanduser("~"), ".pokeparser_token.pickle")
CREDS_FILE = os.path.join(os.path.expanduser("~"), ".pokeparser_credentials.json")


def is_configured() -> bool:
    return GDRIVE_AVAILABLE and os.path.exists(CREDS_FILE)


def authenticate() -> object:
    """
    Run OAuth2 flow. Opens browser for user to authorise.
    Returns a Google Drive service object, or None on failure.
    """
    if not GDRIVE_AVAILABLE:
        return None

    creds = None
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "rb") as f:
            creds = pickle.load(f)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not os.path.exists(CREDS_FILE):
                return None
            flow = InstalledAppFlow.from_client_secrets_file(CREDS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        with open(TOKEN_FILE, "wb") as f:
            pickle.dump(creds, f)

    return build("drive", "v3", credentials=creds)


def get_or_create_folder(service, folder_name: str) -> str:
    """Return the Drive folder ID, creating it if it doesn't exist."""
    query = (
        f"name='{folder_name}' and mimeType='application/vnd.google-apps.folder'"
        " and trashed=false"
    )
    results = service.files().list(q=query, fields="files(id, name)").execute()
    items = results.get("files", [])
    if items:
        return items[0]["id"]
    # Create it
    meta = {
        "name": folder_name,
        "mimeType": "application/vnd.google-apps.folder",
    }
    folder = service.files().create(body=meta, fields="id").execute()
    return folder["id"]


def upload_file(local_path: str, drive_folder_name: str) -> str:
    """
    Upload a file to Google Drive in the specified folder.
    Returns the web view link, or raises on failure.
    """
    service = authenticate()
    if not service:
        raise RuntimeError("Google Drive not authenticated. Run setup first.")

    folder_id = get_or_create_folder(service, drive_folder_name)
    filename = os.path.basename(local_path)

    # Check if file already exists in folder (update instead of duplicate)
    query = f"name='{filename}' and '{folder_id}' in parents and trashed=false"
    existing = service.files().list(q=query, fields="files(id)").execute().get("files", [])

    media = MediaFileUpload(
        local_path,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        resumable=True,
    )

    if existing:
        file_id = existing[0]["id"]
        service.files().update(fileId=file_id, media_body=media).execute()
        result = service.files().get(fileId=file_id, fields="webViewLink").execute()
    else:
        meta = {"name": filename, "parents": [folder_id]}
        result = service.files().create(
            body=meta, media_body=media, fields="webViewLink"
        ).execute()

    return result.get("webViewLink", "")


def save_credentials_path(path: str):
    """Copy the credentials JSON path into the expected location."""
    import shutil
    shutil.copy(path, CREDS_FILE)
