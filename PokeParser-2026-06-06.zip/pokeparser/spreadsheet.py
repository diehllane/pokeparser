"""
spreadsheet.py
Builds the PokeParser output spreadsheet using openpyxl.
Applies green highlighting to:
  - IV values of 30 or 31
  - Nature column when nature matches Smogon's recommended list
"""

import os
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from smogon_lookup import get_recommended_natures

# ── Colours ────────────────────────────────────────────────────────────────────
POKEMON_YELLOW  = "FFCA09"
POKEMON_BLUE    = "3667AF"
HEADER_BLUE     = "2A5298"
GOOD_GREEN      = "4CAF50"
GOOD_GREEN_FONT = "FFFFFF"
ALT_ROW         = "F5F5F5"
WHITE           = "FFFFFF"
DARK_TEXT       = "1A1A2E"
ERROR_RED       = "FF5252"

GREEN_FILL  = PatternFill("solid", fgColor=GOOD_GREEN)
NORMAL_FILL = PatternFill("solid", fgColor=WHITE)

thin_border = Border(
    left=Side(style="thin", color="CCCCCC"),
    right=Side(style="thin", color="CCCCCC"),
    top=Side(style="thin", color="CCCCCC"),
    bottom=Side(style="thin", color="CCCCCC"),
)

# ── Column Layout ──────────────────────────────────────────────────────────────
HEADERS = [
    "File",
    "Pokemon", "Level", "Shiny", "Pokedex", "Type", "Nature",
    "Happiness", "Ability", "Catcher",
    # HP
    "HP Total", "HP Max", "HP IV", "HP EV",

    # Atk
    "Atk", "Atk IV", "Atk EV",
    # Def
    "Def", "Def IV", "Def EV",
    # Spec Atk
    "Spec Atk", "Spec Atk IV", "Spec Atk EV",
    # Spec Def
    "Spec Def", "Spec Def IV", "Spec Def EV",
    # Speed
    "Speed", "Speed IV", "Speed EV",
    # Meta
    "Parse Errors",
]

# Which column letters hold IV values (for green highlighting at 30/31)
IV_COLS = {
    "HP IV", "Atk IV", "Def IV",
    "Spec Atk IV", "Spec Def IV", "Speed IV",
}

# Map result dict keys → header names
KEY_MAP = {
    "file":         "File",
    "pokemon":      "Pokemon",
    "level":        "Level",
    "shiny":        "Shiny",
    "pokedex":      "Pokedex",
    "type":         "Type",
    "nature":       "Nature",
    "happiness":    "Happiness",
    "ability":      "Ability",
    "catcher":      "Catcher",
    "hp_current":   "HP Total",
    "hp_max":       "HP Max",
    "hp_iv":        "HP IV",
    "hp_ev":        "HP EV",

    "atk":          "Atk",
    "atk_iv":       "Atk IV",
    "atk_ev":       "Atk EV",
    "def":          "Def",
    "def_iv":       "Def IV",
    "def_ev":       "Def EV",
    "spec_atk":     "Spec Atk",
    "spec_atk_iv":  "Spec Atk IV",
    "spec_atk_ev":  "Spec Atk EV",
    "spec_def":     "Spec Def",
    "spec_def_iv":  "Spec Def IV",
    "spec_def_ev":  "Spec Def EV",
    "speed":        "Speed",
    "speed_iv":     "Speed IV",
    "speed_ev":     "Speed EV",
    "parse_errors": "Parse Errors",
}


def _col_index(header: str) -> int:
    """Return 1-based column index for a header name."""
    return HEADERS.index(header) + 1


def build_spreadsheet(results: list, output_path: str) -> str:
    """
    Build the output .xlsx from a list of parsed result dicts.
    Returns the path to the written file.
    """
    wb = Workbook()
    ws = wb.active
    ws.title = "PokeParser Results"

    # ── Header row ──────────────────────────────────────────────────────────
    header_fill  = PatternFill("solid", fgColor=HEADER_BLUE)
    header_font  = Font(bold=True, color=POKEMON_YELLOW, size=11,
                        name="Segoe UI")
    header_align = Alignment(horizontal="center", vertical="center",
                             wrap_text=True)

    for col_idx, header in enumerate(HEADERS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill   = header_fill
        cell.font   = header_font
        cell.alignment = header_align
        cell.border = thin_border

    ws.row_dimensions[1].height = 32
    ws.freeze_panes = "A2"

    # ── Data rows ────────────────────────────────────────────────────────────
    for row_num, result in enumerate(results, start=2):
        # Determine recommended natures for this Pokemon
        pokemon_name = result.get("pokemon") or ""
        recommended_natures = set()
        if pokemon_name:
            try:
                recommended_natures = get_recommended_natures(pokemon_name)
            except Exception:
                pass

        alt_fill = PatternFill("solid", fgColor=ALT_ROW if row_num % 2 == 0 else WHITE)

        for col_idx, header in enumerate(HEADERS, start=1):
            # Get value from result dict
            dict_key = next((k for k, v in KEY_MAP.items() if v == header), None)
            if dict_key == "parse_errors":
                value = ", ".join(result.get("parse_errors", [])) or ""
            elif dict_key:
                value = result.get(dict_key)
                if value is None:
                    value = ""
            else:
                value = ""

            # Shiny: boolean → Yes/No
            if header == "Shiny":
                value = "Yes" if value else "No"

            cell = ws.cell(row=row_num, column=col_idx, value=value)
            cell.border = thin_border
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.font = Font(name="Segoe UI", size=10, color=DARK_TEXT)

            # ── Green IV highlight ─────────────────────────────────────────
            if header in IV_COLS and isinstance(value, int) and value >= 30:
                cell.fill = GREEN_FILL
                cell.font = Font(name="Segoe UI", size=10, bold=True,
                                 color=GOOD_GREEN_FONT)

            # ── Green Nature highlight ────────────────────────────────────
            elif header == "Nature" and value and value in recommended_natures:
                cell.fill = GREEN_FILL
                cell.font = Font(name="Segoe UI", size=10, bold=True,
                                 color=GOOD_GREEN_FONT)

            # ── Error cell highlight ──────────────────────────────────────
            elif header == "Parse Errors" and value:
                cell.fill = PatternFill("solid", fgColor="FFE0E0")
                cell.font = Font(name="Segoe UI", size=9, italic=True,
                                 color=ERROR_RED)

            # ── Alternate row tint ────────────────────────────────────────
            else:
                cell.fill = alt_fill

        ws.row_dimensions[row_num].height = 20

    # ── Column widths ────────────────────────────────────────────────────────
    col_widths = {
        "File": 30,
        "Pokemon": 18, "Level": 8, "Shiny": 8,
        "Pokedex": 9, "Type": 11, "Nature": 11,
        "Happiness": 11, "Ability": 18, "Catcher": 14,
        "HP Total": 10, "HP Max": 10, "HP IV": 8, "HP EV": 8,

        "Atk": 8, "Atk IV": 8, "Atk EV": 8,
        "Def": 8, "Def IV": 8, "Def EV": 8,
        "Spec Atk": 10, "Spec Atk IV": 11, "Spec Atk EV": 11,
        "Spec Def": 10, "Spec Def IV": 11, "Spec Def EV": 11,
        "Speed": 8, "Speed IV": 10, "Speed EV": 10,
        "Parse Errors": 20,
    }
    for col_idx, header in enumerate(HEADERS, start=1):
        ws.column_dimensions[get_column_letter(col_idx)].width = col_widths.get(header, 12)

    # ── Add a summary count at the bottom ────────────────────────────────────
    last_row = len(results) + 2
    ws.cell(row=last_row, column=1,
            value=f"Total: {len(results)} Pokemon parsed").font = Font(
        bold=True, italic=True, color=HEADER_BLUE, name="Segoe UI"
    )

    wb.save(output_path)
    return output_path


def make_output_path(output_dir: str) -> str:
    """Generate a timestamped output filename."""
    ts = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    return os.path.join(output_dir, f"PokeParser-{ts}.xlsx")
